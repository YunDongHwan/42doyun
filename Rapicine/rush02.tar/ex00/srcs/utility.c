/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utility.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jayi <jayi@student.42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/10/31 22:58:55 by jayi              #+#    #+#             */
/*   Updated: 2020/11/01 19:57:43 by jayi             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "utility.h"

void	convert_to_digit(char *str)
{
	int		idx;

	idx = 1;
	if (str[0] == '\0')
		return ;
	while (str[idx])
	{
		str[idx++] = '0';
	}
}

int		is_zeros(char *str)
{
	if (*str == '\0')
		return (0);
	while (*str == '0')
		str++;
	return (*str == '\0');
}
