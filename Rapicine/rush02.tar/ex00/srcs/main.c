/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jayi <jayi@student.42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/11/01 02:04:38 by jayi              #+#    #+#             */
/*   Updated: 2020/11/01 21:31:38 by jayi             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "parsing.h"

void	start(char *str)
{
	g_result = 0;
	process(str, ft_strlen(str), 0);
	print_node(g_result);
	free_memories();
}

int		main(int argc, char *argv[])
{
	char	*target;
	char	*file_name;

	if (argc == 2 || argc == 3)
	{
		target = argc == 2 ? argv[1] : argv[2];
		file_name = argc == 2 ? "numbers.dict" : argv[1];
		if (check_argv(target))
		{
			if (init_dict(file_name))
				start(target);
			else
				dict_error();
		}
		else
		{
			argv_error();
		}
	}
	return (0);
}
