/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parsing.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jayi <jayi@student.42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/11/01 02:04:38 by jayi              #+#    #+#             */
/*   Updated: 2020/11/01 22:28:09 by jayi             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "parsing.h"

void	push_items(char *str)
{
	int		idx[2];

	idx[STR] = 0;
	idx[DICT] = 0;
	while (str[idx[STR]])
	{
		if (is_space(str[idx[STR]]))
		{
			idx[STR]++;
			continue;
		}
		g_item_dict.items[idx[DICT]].key = pick_key(str, idx[STR]);
		while (str[idx[STR]] >= '0' && str[idx[STR]] <= '9')
			idx[STR]++;
		while (is_space(str[idx[STR]]))
			idx[STR]++;
		if (str[idx[STR]] == ':')
			idx[STR]++;
		while (is_space(str[idx[STR]]))
			idx[STR]++;
		g_item_dict.items[idx[DICT]++].value = pick_value(str, idx[STR]);
		while (str[idx[STR]] >= 32 && str[idx[STR]] <= 126)
			idx[STR]++;
	}
	g_item_dict.size = idx[DICT];
}

void	count_items(char *str)
{
	int		count;

	count = 0;
	while (*str)
	{
		if (*str == '\n')
			count++;
		str++;
	}
	g_item_dict.items = (t_item *)malloc(sizeof(t_item) * count);
	g_item_dict.size = 0;
}

void	push_digits(void)
{
	int		idx_item;
	int		idx_digit;
	int		idx_zero;

	idx_zero = 0;
	idx_item = 0;
	idx_digit = 0;
	while (idx_item < g_item_dict.size)
	{
		if (g_item_dict.items[idx_item].key[0] == '1')
		{
			idx_zero = 1;
			while (g_item_dict.items[idx_item].key[idx_zero] == '0')
				idx_zero++;
			if (g_item_dict.items[idx_item].key[idx_zero] == '\0' &&
					idx_zero > MIN_DIGIT)
				g_digit_dict.items[idx_digit++] = g_item_dict.items[idx_item];
		}
		idx_item++;
	}
}

void	count_digits(void)
{
	int		idx_item;
	int		idx_digit;
	int		idx_zero;
	int		count;

	idx_zero = 0;
	idx_item = 0;
	idx_digit = 0;
	count = 0;
	while (idx_item < g_item_dict.size)
	{
		if (g_item_dict.items[idx_item].key[0] == '1')
		{
			idx_zero = 1;
			while (g_item_dict.items[idx_item].key[idx_zero] == '0')
				idx_zero++;
			if (g_item_dict.items[idx_item].key[idx_zero] == '\0' &&
					idx_zero > MIN_DIGIT)
				count++;
		}
		idx_item++;
	}
	g_digit_dict.items = (t_item *)malloc(sizeof(t_item) * count);
	g_digit_dict.size = count;
}

int		init_dict(char *file_name)
{
	char	*content;
	int		idx;

	idx = 0;
	content = read_all(file_name);
	count_items(content);
	if (g_item_dict.items == 0)
		return (0);
	push_items(content);
	if (check_item_dict() == 0)
		return (0);
	count_digits();
	if (g_digit_dict.items == 0)
		return (0);
	push_digits();
	free(content);
	return (1);
}
