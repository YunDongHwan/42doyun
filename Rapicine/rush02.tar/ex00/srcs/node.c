/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   node.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jayi <jayi@student.42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/10/31 14:09:36 by jayi              #+#    #+#             */
/*   Updated: 2020/11/01 04:41:38 by jayi             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "node.h"

t_node	*create_node(char *str)
{
	t_node	*new_node;

	if (!(new_node = (t_node *)malloc(sizeof(t_node))))
	{
		return (0);
	}
	new_node->value = str;
	new_node->next = 0;
	return (new_node);
}

void	add_node(t_node **head, char *str)
{
	t_node	*node;

	if (*head == 0)
	{
		*head = create_node(str);
		return ;
	}
	node = *head;
	while (node->next)
	{
		node = node->next;
	}
	node->next = create_node(str);
}

void	print_node(t_node *head)
{
	t_node	*node;

	node = head;
	while (node)
	{
		if (node != head)
			write(1, " ", 1);
		ft_putstr(node->value);
		node = node->next;
	}
	write(1, "\n", 1);
}
