/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   memory.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jayi <jayi@student.42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/11/01 17:46:54 by jayi              #+#    #+#             */
/*   Updated: 2020/11/01 20:01:59 by jayi             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "memory.h"

int		free_node(t_node *node)
{
	int		result;

	if (node == NULL)
		return (1);
	result = 1;
	result *= free_node(node->next);
	free(node);
	return (1);
}

int		free_result(void)
{
	return (free_node(g_result));
}

int		free_dicts(void)
{
	int		idx;

	idx = 0;
	while (idx < g_item_dict.size)
	{
		free(g_item_dict.items[idx].key);
		free(g_item_dict.items[idx].value);
		idx++;
	}
	free(g_item_dict.items);
	free(g_digit_dict.items);
	return (1);
}

int		free_memories(void)
{
	int		result;

	result = 1;
	result *= free_result();
	result *= free_dicts();
	return (result);
}
