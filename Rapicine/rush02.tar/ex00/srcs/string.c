/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   string.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jayi <jayi@student.42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/10/31 22:26:04 by jayi              #+#    #+#             */
/*   Updated: 2020/11/01 04:39:27 by jayi             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "string.h"

void	ft_strcpy_range(char *dest, char *src, int start, int end)
{
	int		idx;

	idx = 0;
	while (start < end)
		dest[idx++] = src[start++];
	dest[idx] = '\0';
}

int		ft_strlen(char *str)
{
	int		count;

	count = 0;
	while (*str)
	{
		count++;
		str++;
	}
	return (count);
}

void	ft_init_str(char *str, int length)
{
	int		idx;

	idx = 0;
	while (idx < length)
	{
		str[idx++] = 0;
	}
}

int		ft_strcmp(char *str1, char *str2)
{
	while (*str1 == *str2 && *str1 && *str2)
	{
		str1++;
		str2++;
	}
	return (*str1 - *str2);
}

void	ft_putstr(char *str)
{
	while (*str)
	{
		write(1, str, 1);
		str++;
	}
}
