/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   dictionary.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jayi <jayi@student.42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/10/31 23:18:31 by jayi              #+#    #+#             */
/*   Updated: 2020/11/01 03:07:23 by jayi             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "dictionary.h"

char	*get_value(char *key)
{
	int		idx;

	idx = 0;
	while (idx < g_item_dict.size)
	{
		if (ft_strcmp(key, g_item_dict.items[idx].key) == 0)
			return (g_item_dict.items[idx].value);
		idx++;
	}
	return (0);
}

int		is_digits(char *str)
{
	int		idx;

	if (str[0] == 0 || str[0] == '0')
		return (0);
	idx = 0;
	while (idx < g_digit_dict.size)
	{
		if (ft_strcmp(str, g_digit_dict.items[idx].key) == 0)
			return (1);
		idx++;
	}
	return (0);
}
