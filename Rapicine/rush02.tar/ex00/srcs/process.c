/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   process.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jayi <jayi@student.42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/10/31 23:15:59 by jayi              #+#    #+#             */
/*   Updated: 2020/11/01 22:15:48 by jayi             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "process.h"

void	after_logic(char *strs[2], int idxes[2])
{
	idxes[RAW]++;
	free(strs[CUR]);
}

void	init_process(char *strs[2], int idxes[2], int length)
{
	idxes[RAW] = 0;
	idxes[WAIT] = 0;
	strs[WAIT] = (char *)malloc(sizeof(char) * (length + 1));
	ft_init_str(strs[WAIT], length + 1);
}

void	next(char *strs[2], int idxes[2], char *raw_str, int depth)
{
	process(strs[WAIT], ft_strlen(strs[WAIT]), depth + 1);
	if (raw_str[idxes[RAW]] != '0' && !is_zeros(strs[WAIT]))
		add_node(&g_result, get_value(strs[CUR]));
	ft_init_str(strs[WAIT], ft_strlen(strs[WAIT]));
	idxes[WAIT] = 0;
}

void	logic(char *strs[2], int idxes[2], char *raw_str, int depth)
{
	convert_to_digit(strs[CUR]);
	if (get_value(strs[CUR]) && !is_digits(strs[CUR]))
		next(strs, idxes, raw_str, depth);
	else
	{
		strs[WAIT][idxes[WAIT]++] = raw_str[idxes[RAW]];
		strs[CUR][0] = '1';
		if (is_digits(strs[CUR]))
			next(strs, idxes, raw_str, depth);
	}
}

void	process(char *raw_str, int length, int depth)
{
	char	*strs[2];
	int		idxes[2];
	int		digit;

	init_process(strs, idxes, length);
	if (raw_str[0] == '0' && depth == 0)
	{
		add_node(&g_result, get_value(raw_str));
		return ;
	}
	while (idxes[RAW] < length)
	{
		digit = length - idxes[RAW];
		strs[CUR] = (char *)malloc(sizeof(char) * (digit + 1));
		ft_strcpy_range(strs[CUR], raw_str, idxes[RAW], length);
		if (digit == 2 && raw_str[idxes[RAW]] == '1' && get_value(strs[CUR]))
		{
			next(strs, idxes, raw_str, depth);
			idxes[RAW]++;
		}
		else
			logic(strs, idxes, raw_str, depth);
		after_logic(strs, idxes);
	}
	free(strs[WAIT]);
}
