/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parsing_tool.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jayi <jayi@student.42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/11/01 04:45:04 by jayi              #+#    #+#             */
/*   Updated: 2020/11/01 22:33:35 by jayi             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "parsing.h"

char	*read_all(char *file_name)
{
	int		fd[2];
	int		count;
	char	buf[1];
	char	*content;

	count = 0;
	fd[COUNT] = open(file_name, O_RDONLY);
	fd[READ] = open(file_name, O_RDONLY);
	if (fd[COUNT] < 0 || fd[READ] < 0)
	{
		write(1, "Dict Error\n", 11);
		close(fd[COUNT]);
		close(fd[READ]);
		return (0);
	}
	while (read(fd[COUNT], buf, 1))
		count++;
	content = (char *)malloc(sizeof(char) * (count + 1));
	read(fd[READ], content, count);
	content[count] = '\0';
	close(fd[COUNT]);
	close(fd[READ]);
	return (content);
}

int		check_item_dict(void)
{
	int		idx;

	idx = 0;
	while (idx < g_item_dict.size)
	{
		if (g_item_dict.items[idx].key == 0 ||
				g_item_dict.items[idx].value == 0)
			return (0);
		idx++;
	}
	return (1);
}

int		is_space(char symbol)
{
	if (symbol == '\t' || symbol == ' ' || symbol == '\n' ||
			symbol == '\r' || symbol == '\v' || symbol == '\f')
		return (1);
	return (0);
}

char	*pick_key(char *str, int start)
{
	int		count;
	int		idx_str;
	int		idx_res;
	char	*result;

	count = 0;
	idx_res = 0;
	idx_str = start;
	while (str[idx_str] >= '0' && str[idx_str] <= '9')
	{
		count++;
		idx_str++;
	}
	if (count == 0)
		return (0);
	result = (char *)malloc(sizeof(char) * (count + 1));
	idx_str = start;
	while (str[idx_str] >= '0' && str[idx_str] <= '9')
		result[idx_res++] = str[idx_str++];
	result[idx_res] = '\0';
	return (result);
}

char	*pick_value(char *str, int start)
{
	int		count;
	int		idx_str;
	int		idx_res;
	char	*result;

	count = 0;
	idx_res = 0;
	idx_str = start;
	while (str[idx_str] >= 32 && str[idx_str] <= 126)
	{
		idx_str++;
		count++;
	}
	if (count == 0)
		return (0);
	result = (char *)malloc(sizeof(char) * (count + 1));
	idx_str = start;
	while (str[idx_str] >= 32 && str[idx_str] <= 126)
		result[idx_res++] = str[idx_str++];
	while (result[--idx_res] == ' ')
		result[idx_res] = '\0';
	return (result);
}
