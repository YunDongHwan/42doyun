/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   error.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jayi <jayi@student.42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/11/01 03:53:15 by jayi              #+#    #+#             */
/*   Updated: 2020/11/01 22:14:51 by jayi             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "error.h"

void	argv_error(void)
{
	write(1, "Error\n", 6);
}

void	dict_error(void)
{
	write(1, "Dict Error\n", 11);
}

void	malloc_error(void)
{
	write(1, "Error\n", 6);
}

int		check_argv(char *str)
{
	int idx;

	idx = 0;
	if (str == 0 || str[0] == '\0')
		return (0);
	if (str[0] == '0' && str[1] != '\0')
		return (0);
	while (str[idx])
	{
		if (!(str[idx] >= '0' && str[idx] <= '9'))
			return (0);
		idx++;
	}
	return (1);
}
