/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   dictionary.h                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jayi <jayi@student.42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/10/31 23:21:19 by jayi              #+#    #+#             */
/*   Updated: 2020/11/01 03:10:04 by jayi             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef DICTIONARY_H
# define DICTIONARY_H

# include "string.h"

typedef struct		s_item
{
	char			*key;
	char			*value;
}					t_item;

typedef struct		s_dict
{
	t_item			*items;
	int				size;
}					t_dict;

t_dict				g_digit_dict;
t_dict				g_item_dict;

char				*get_value(char *key);
int					is_digits(char *str);

#endif
