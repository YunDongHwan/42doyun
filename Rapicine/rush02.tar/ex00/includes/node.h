/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   node.h                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jayi <jayi@student.42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/10/31 14:09:36 by jayi              #+#    #+#             */
/*   Updated: 2020/11/01 03:11:12 by jayi             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef NODE_H
# define NODE_H
# include <unistd.h>
# include <stdlib.h>
# include "string.h"

typedef struct		s_node
{
	char			*value;
	struct s_node	*next;
}					t_node;

t_node				*g_result;
t_node				*create_node(char *str);
void				add_node(t_node **head, char *str);
void				print_node(t_node *head);

#endif
