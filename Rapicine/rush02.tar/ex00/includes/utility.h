/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utility.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jayi <jayi@student.42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/10/31 22:59:11 by jayi              #+#    #+#             */
/*   Updated: 2020/11/01 03:11:40 by jayi             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef UTILITY_H
# define UTILITY_H
# include "string.h"
# include "dictionary.h"

extern t_dict g_digit_dict;
extern t_dict g_item_dict;

int		is_zeros(char *str);
void	convert_to_digit(char *str);

#endif
