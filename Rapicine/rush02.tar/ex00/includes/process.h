/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   process.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jayi <jayi@student.42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/10/31 22:48:59 by jayi              #+#    #+#             */
/*   Updated: 2020/11/01 17:22:50 by jayi             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PROCESS_H
# define PROCESS_H
# define RAW 0
# define WAIT 1
# define CUR 0
# define WAIT 1

# include "parsing.h"
# include "utility.h"
# include "node.h"
# include "string.h"
# include <stdlib.h>

extern	t_dict g_item_dict;
extern	t_dict g_digit_dict;
void	after_logic(char *strs[2], int idxes[2]);
void	init_process(char *strs[2], int idxes[2], int length);
void	next(char *strs[2], int idxes[2], char *raw_str, int depth);
void	logic(char *strs[2], int idxes[2], char *raw_str, int depth);
void	process(char *raw_str, int length, int depth);

#endif
