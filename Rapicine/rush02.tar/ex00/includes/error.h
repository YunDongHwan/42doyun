/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   error.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jayi <jayi@student.42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/11/01 03:53:15 by jayi              #+#    #+#             */
/*   Updated: 2020/11/01 17:59:21 by jayi             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef ERROR_H
# define ERROR_H
# include <unistd.h>

void	argv_error(void);
void	dict_error(void);
void	malloc_error(void);
int		check_argv(char *str);

#endif
