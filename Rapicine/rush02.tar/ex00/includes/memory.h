/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   memory.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jayi <jayi@student.42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/11/01 17:46:54 by jayi              #+#    #+#             */
/*   Updated: 2020/11/01 20:01:37 by jayi             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MEMORY_H
# define MEMORY_H
# include "node.h"
# include "dictionary.h"

extern t_node *g_result;
extern t_dict g_item_dict;
extern t_dict g_digit_dict;

int		free_node(t_node *node);
int		free_result();
int		free_dicts();
int		free_memories();

#endif
