/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   string.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jayi <jayi@student.42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/10/31 22:26:04 by jayi              #+#    #+#             */
/*   Updated: 2020/11/01 02:36:49 by jayi             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef STRING_H
# define STRING_H
# include <unistd.h>

void	ft_strcpy_range(char *dest, char *src, int start, int end);
int		ft_strlen(char *str);
void	ft_init_str(char *str, int length);
int		ft_strcmp(char *str1, char *str2);
void	ft_putstr(char *str);

#endif
