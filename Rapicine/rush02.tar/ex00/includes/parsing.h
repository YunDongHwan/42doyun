/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parsing.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jayi <jayi@student.42seoul.kr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/11/01 02:02:48 by jayi              #+#    #+#             */
/*   Updated: 2020/11/01 18:27:17 by jayi             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PARSING_H
# define PARSING_H
# include <fcntl.h>
# include <unistd.h>
# include <stdlib.h>
# include "dictionary.h"
# include "node.h"
# include "string.h"
# include "process.h"
# include "error.h"
# include "memory.h"
# define COUNT 0
# define READ 1
# define STR 0
# define DICT 1
# define MIN_DIGIT 1

extern t_dict		g_item_dict;
extern t_dict		g_digit_dict;
extern t_node		*g_result;

char	*read_all(char *file_name);
int		is_space(char symbol);
char	*pick_key(char *str, int start);
char	*pick_value(char *str, int start);
void	push_items(char *str);
void	count_items(char *str);
int		check_item_dict(void);
void	push_digits(void);
void	count_digits(void);
int		init_dict(char *file_name);

#endif
